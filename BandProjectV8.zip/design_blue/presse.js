pressetexte = [{
  text: ".....2009 gegründet, gilt die Wiener Truppe als eine der arriviertesten Tribute-Bands Euopas. \"Eine Reise durch endlose Klanglandschaften von Pink Floyd, ein Sound, der näher am Original nicht sein könnte\", jubelt die Passauer Neue Presse. .......",
  link: "img/2017_SimmCity.jpg",
  linktext: "Österreich"
}, {
  text: "....Coverband lässt Neuberinhaus beben 300 Fans haben sich in Reichenbach von der unsterblichen Rockmusik der 1970er und 1980er Jahre sowie einer Licht- und Multimedia-Show verzaubern lassen. Ein Besucher: Ich war überrascht, hier soetwas zu erleben. …….",
  link: "img/Freie_Presse.pdf",
  linktext: "Freie Presse"
}, {
  text: "Coverbands der Stones oder von AC/DC stehen vor einem Problem: Das einzigartige Charisma der Stars auf die Bühne zu bringen, ohne ins peinliche Kopieren zu verfallen, ist eine Herausforderung. Nicht so, würde man meinen, bei Pink Floyd: Die Ausnahmeband hat live vor allem mit groß angelegter Show und weniger mit Präsenz der Musiker gepunktet. Und sollte daher besser geeignet sein für eine Tribute-Show. Dass das nicht stimmt, zeigen viele internationale Tribute-Beispiele, die zwar perfekt Sound und Optik kopieren, aber auch den heftigsten Fan kalt lassen. In Wien aber gibt es die elfköpfige Floyd Division. Und die fügen einer musikalisch und optisch hervorragenden Umsetzung des Liveerlebnisses (runde Leinwand, Videoprojektion und mehr) noch etwas Entscheidendes bei: Spürbaren Enthusiasmus nämlich, der ihre Tribute-Shows besonders macht. Am 4. Februar in der SIMM City gibt es eine \"Psychedelic Journey\" durch die Geschichte Pink Floyds…….",
  link: "https://kurier.at/gewinnspiele/ein-gruebler-elf-floyd-fans/239.442.641",
  linktext: "Kurier"
}, {
  text: "\"Alle \"Floyd Division\"-Musiker sorgten mit ihrem exzellenten Können dafür, dass für circa drei Stunden der urtypische Pink-Floyd-Sound durch die Kufa wehte. Mit Titeln wie \"Brain damaged\" stellte \"Floyd Division\" das im Jahr 1973 weltweit am stärksten verkaufte Album \"The dark side of the moon\" in den Mittelpunkt. Die Menschen im Saal wippten mit den Füßen und Textsichere sangen leise mit. Ein Höhepunkt des Abends war \"Dogs\" vom 1977er-Album \"Animals\"...\"",
  link: "",
  linktext: "Lausitzer Rundschau"
}, {
  text: "\"Pink Floyd ist Pop History! Deshalb kommen Freitag bei der Krone Konzertreihe im Eboardmuseum Klagenfurt auch die Gruppe \"Floyd Division auf die Bühne. Eboard Chef Gert Prix: Die österreichische Gruppe ist selbst schon beinahe Kult. Sie hat schon so viele Fans bei uns, dass wir sie nochmal einladen mussten...\"",
  link: "",
  linktext: "Kronen Zeitung Klagenfurt"
}, {
  text: "\"Es gibt Coverbands und Tributebands. Es gibt gute, sehr gute und schlechte. Pink Floyd stellen dafür ein bevorzugtes Objekt des Tributes dar. Es gibt Bands die beschränken sich dabei auf hochwertige Musik mit tollem Licht, andere machen eine bombastische Show, kaufen sich einen bekannten Sänger ein und kriegen musikalisch doch nix auf die Reihe..... Das es viel besser geht, beweisen Floyd Division aus Österreich.....Nach der \"Australian Pink Floyd Show\" und \"Britfloyd\", steht die Band qualitativ ganz weit oben in Europa\"",
  link: "img/DresdenKritik.jpg",
  linktext: "access2music"
}, {
  text: "\"Die grandiose österreichische Tribute-Band \"Floyd Division\" war zu Gast in der Spinnerei zu Traun, um ihren Heroen Pink Floyd zu huldigen. Das äußerst zahlreich erschienene Publikum war fasziniert von der hochwertigen Darbietung, die so nah und detailverliebt wie möglich am Original war.\"",
  link: "https://www.traunimbild.at/events/view/981/page:1",
  linktext: "Traun Im Bild"
}, {
  text: "\"Die Pink Floyd Tribute Band Floyd Division mit Sänger Roman Bischof tourte gerade noch durch Deutschland. Die heimischen Fans.... waren jetzt im Pottschacher Kulturhaus am Zug. Veranstalter Harry Brawenec und die fast 300 Besucher fanden das Konzert unisono genial.",
  link: "img/PottschachKritik.jpg",
  linktext: "Bezirksblätter Nö"
}, {
  text: "\"Pink Floyd – Eine Legende wird zelebriert.....Etwa 1200 Besucher erlebten am Freitagabend eine von Floyd Division perfekt inszenierte Multimediashow mit den Songs der britischen Rockband auf der Seebühne Kriebstein.....Das Publikum saugt die in solider Handarbeit in brillantem Sound abgelieferten Stücke dankbar auf\"",
  link: "img/KriebsteinKritik.jpg",
  linktext: "Freie Presse Sachsen"
}, {
  text: "\"Floyd Division sind ja so nah dran an Floyd, unglaublich. Es gab wirklich viele Momente, wo man glauben konnte, die Originale spielen da auf der Bühne. .... Die Stimme ist für mich auch die, die unter den Floyd-Coverbands am dichtesten am Original dran ist. Auch die beiden Damen im Hintergrund tragen nicht unwesentlich zum Floyd-Sound bei, machen dann bei \"The great Gig in the Sky\" ihr Meisterstück!.....Ja, und die beiden Gitarristen spielen wirklich wie Gilmour himself! Einfach nur genial!\"",
  link: "http://www.bruder-franziskus.de/",
  linktext: "Bruder Franziskus - Pink Floyd Fanbase"
}, {
  text: "\"Gut 230 Besucher strömten letzten Samstag aus dem gesamten Bundesland nach Frauental....Perfektes Wetter und angenehme Temperaturen waren zudem gute Begleiter für eine psychodelische Zeitreise rund um die Hits der Kultgruppe Pink Floyd.......mit \"Shine on your crazy diamonds\" den Abend für eine Erinnerungswürdige, musikalische Zeitreise bereiteten. Perfekte Pink Floyd - Covers ausgezeichneter Musiker mit Sänger und Mastermind Roman Bischof trafen auf sphärische Lichttechnik und begeisterten Floyd-Fans\"",
  link: "img/BluegarageKritik2.jpg",
  linktext: "Bezirksblatt Deutschlandsberg"
}, {
  text: "\"Pink Floyd hätte im Vergleich zu \"Floyd Division\" eine größere Bühne gebraucht, das war dann aber schon alles, was beide Bands unterscheidet. Musikalisch lieferten die Musiker einfach Pink Floyd pur ab\"",
  link: "img/Pottschach_Kritik.jpg",
  linktext: "Bezirksblätter Nö"
}, {
  text: "\"Bei Tageslicht wurde dann mit „in the flesh“ begonnen und man hat sofort gemerkt, dass das Publikum beinahe auf’s Essen vergessen hat.... Kolportierten Gerüchte zu Folge soll Ewald sogar gesagt haben „Die spielen in einer anderen Liga!\"",
  link: "http://www.pulse-and-spirit.com/konzerte/floyd-division-15-7-2011-traun-hauptplatz/",
  linktext: "Pulse & Spirit"
}, {
  text: "\"Die Wiener \"Floyd Division\" sind eine europaweit anerkannte Tribute-Band und bemühen sich mit großem Aufwand und in größter Perfektion um originalgetreue Wiedergabe. Zeitlose Songs wie \"Wish You Were Here\" oder \"Comfortably Numb\" drehten für viele Besucher das Rad der Zeit um einige Jahrzehnte zurück und das es noch viele Floyd-Fans gibt, zeigte der sehr gut gefüllte Trauner Hauptplatz.\"",
  link: "https://www.traunimbild.at/events/view/700",
  linktext: "http://www.traunimbild.at/events/view/700"
}, {
  text: "\"Die Band schaffte es mit außergewöhnlichen handwerklichen Mitteln und der visuellen Umsetzung genau diese dichte, sphärische, emotionale Stimmung zu zelebrieren, für die das Original berühmt war. Ein Abend mit einem Genuss für sämtliche Sinne, eine Reise durch endlose Klanglandschaften von Pink Floyd, ein Sound, der näher am Original nicht sein könnte\"",
  link: "img/BluegarageKritik.jpg",
  linktext: "Bezirksblatt Deutschlandsberg"
}, {
  text: "\"Hühepunkt war die österreichische Pink Floyd Tribute Band \"Floyd Division\", die dem Publikum ordentlich einheizte ..... Floyd Division spielte neben bekannten Klassikern auch neue Songs und begeisterte das Publikum mit ihrem unverwechselbaren Sound.\"",
  link: "img/NoenReview",
  linktext: "NÖN"
}];

function createPresseText() {
  tag = "";
  for (let i = 0; i < pressetexte.length; i++) {
    if (i % 2 == 0) {
      tag += "<div class=\"row\">";
    }
    tag += "<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xl-6\">";
    tag += "<p>" + pressetexte[i].text + "</p>";
    if (pressetexte[i].link != "") {
      tag += "<p>" + "Quelle:" +"<a href=\"" + pressetexte[i].link +"\">" + pressetexte[i].linktext +"</a>"+ "</p>";
      console.log(pressetexte[i].link);
    } else {
      tag += "<p>" + "Quelle:" + pressetexte[i].linktext + "</p>";
    }
    tag+="</div>"
    if ((i + 1) % 2 == 0) {
      tag += "</div>";
    }
  }
  console.log(tag)
  document.getElementById("presseStimmen").innerHTML += tag;
}
